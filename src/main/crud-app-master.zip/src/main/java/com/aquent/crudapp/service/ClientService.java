package com.aquent.crudapp.service;

import java.util.List;

import com.aquent.crudapp.domain.Client;

/**
 * Client Operations
 * @author jdunn
 *
 */
public interface ClientService {
	
	/**
	 * Retrieves all of the client records
	 * @return
	 */
	List<Client> listClients();
	
	/**
	 * Retrieves a client record by id
	 * @param id
	 * @return
	 */
	Client readClient(Integer id);
	
	/**
	 * Creates a new client record
	 * @param client
	 * @return
	 */
	Integer createClient(Client client);
	
	/**
	 * Updates an existing client record
	 * @param client
	 */
	void updateClient(Client client);
	
	/**
	 * Deletes a client record by id
	 * @param id
	 */
	void deleteClient(Integer id);
	
	
	/**
	 * Validates populated client data.
	 * @param client
	 * @return
	 */
	List<String> validateClient(Client client);

}

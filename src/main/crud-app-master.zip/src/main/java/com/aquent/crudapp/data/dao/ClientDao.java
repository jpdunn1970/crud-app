package com.aquent.crudapp.data.dao;

import java.util.List;

import com.aquent.crudapp.domain.Client;

/**
 * Operations on the Client Table
 * @author jdunn
 *
 */
public interface ClientDao {

	/**
	 * Retrieves all the client records
	 * @return
	 */
	List<Client> listClients();
	
	/**
	 * Creates a new client record
	 * @param client
	 * @return
	 */
	Integer createClient(Client client);
	
	/**
	 * Retrieves a client record by id
	 * @param id
	 * @return
	 */
	Client readClient(Integer id);
	
	/**
	 * Updates an existing client record
	 * @param client
	 */
	void updateClient(Client client);
	
	/**
	 * Deletes a client record by id
	 * @param id
	 */
	void deleteClient(Integer id);
	
}

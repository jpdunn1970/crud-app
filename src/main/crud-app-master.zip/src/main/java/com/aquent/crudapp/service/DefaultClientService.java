package com.aquent.crudapp.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import com.aquent.crudapp.data.dao.ClientDao;
import com.aquent.crudapp.data.dao.PersonDao;
import com.aquent.crudapp.domain.Client;
import com.aquent.crudapp.domain.Person;

public class DefaultClientService implements ClientService {

	private ClientDao clientDao;
	private PersonDao personDao;
    private Validator validator;
	
    public void setClientDao(ClientDao clientDao) {
    	this.clientDao = clientDao;
    }
    
    public void setPersonDao(PersonDao personDao) {
        this.personDao = personDao;
    }

    public void setValidator(Validator validator) {
        this.validator = validator;
    }
    
	@Override
	public List<Client> listClients() {
		List<Client> clients = clientDao.listClients();
		for (Client client : clients) {
			List<Person> people = personDao.ListClientPeople(client.getClientId());
			client.setPersons(people);
		}
		return clients;
	}

	@Override
	public Client readClient(Integer id) {
		Client client = clientDao.readClient(id);
		List<Person> people = personDao.ListClientPeople(client.getClientId());
		client.setPersons(people);
		return client;
	}

	@Override
	public Integer createClient(Client client) {
		return clientDao.createClient(client);
	}

	@Override
	public void updateClient(Client client) {
		clientDao.createClient(client);

	}

	@Override
	public void deleteClient(Integer id) {
		clientDao.deleteClient(id);

	}

	@Override
	public List<String> validateClient(Client client) {
		 Set<ConstraintViolation<Client>> violations = validator.validate(client);
        List<String> errors = new ArrayList<String>(violations.size());
        for (ConstraintViolation<Client> violation : violations) {
            errors.add(violation.getMessage());
        }
        Collections.sort(errors);
        return errors;
	}

}

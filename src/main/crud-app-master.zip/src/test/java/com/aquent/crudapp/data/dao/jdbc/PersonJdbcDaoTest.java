package com.aquent.crudapp.data.dao.jdbc;

import static org.hamcrest.core.IsEqual.equalTo;

import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.aquent.crudapp.data.dao.PersonDao;
import com.aquent.crudapp.domain.Client;
import com.aquent.crudapp.domain.Person;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/application-beans.xml"})
public class PersonJdbcDaoTest {
	
	@Autowired
	PersonDao personDao;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test_listPeople() {
		List<Person> people = personDao.listPeople();
		Assert.assertThat(people.size(), equalTo(2));
	}
	
	@Test
	public void test_readPerson() {
		Person person = personDao.readPerson(0);
		boolean personFlag = true;
		if (!person.getFirstName().equals("John")) {
			personFlag = false;
		}
		if (!person.getLastName().equals("Smith")) {
			personFlag = false;
		}
		if (!person.getEmailAddress().equals("fake1@aquent.com")) {
			personFlag = false;
		}
		if (!person.getStreetAddress().equals("123 Any St.")) {
			personFlag = false;
		}
		if (!person.getCity().equals("Asheville")) {
			personFlag = false;
		}
		if (!person.getState().equals("NC")) {
			personFlag = false;
		}
		if (!person.getZipCode().equals("28801")) {
			personFlag = false;
		}
		if (!person.getClient().getCompanyName().equals("Aquent")) {
			personFlag = false;
		}
		Assert.assertThat(personFlag, equalTo(true));
	}
	
	@Test
	public void test_updatePerson() {
		Person person = personDao.readPerson(0);
		person.setFirstName("Samuel");
		personDao.updatePerson(person);
		person = personDao.readPerson(0);
		Assert.assertTrue(person.getFirstName().equals("Samuel"));
		
		person.setFirstName("John");
		personDao.updatePerson(person);
	}
	
	@Test
	public void test_createPerson() {
		Person person = new Person();
		person.setFirstName("Joe");
		person.setLastName("Anybody");
		person.setEmailAddress("jany@anywhere.org");
		person.setStreetAddress("456 Any St.");
		person.setCity("Boston");
		person.setState("MA");
		person.setZipCode("02118");
		Client client = new Client();
		client.setClientId(1);
		person.setClient(client);
		
		int id = personDao.createPerson(person);
		Person person2 = personDao.readPerson(id);
		
		boolean personFlag = true;
		if (!person2.getFirstName().equals("Joe")) {
			personFlag = false;
		}
		if (!person2.getLastName().equals("Anybody")) {
			personFlag = false;
		}
		if (!person2.getEmailAddress().equals("jany@anywhere.org")) {
			personFlag = false;
		}
		if (!person2.getStreetAddress().equals("456 Any St.")) {
			personFlag = false;
		}
		if (!person2.getCity().equals("Boston")) {
			personFlag = false;
		}
		if (!person2.getState().equals("MA")) {
			personFlag = false;
		}
		if (!person2.getZipCode().equals("02118")) {
			personFlag = false;
		}
		Assert.assertThat(personFlag, equalTo(true));
		
		personDao.deletePerson(2);
	}
	
	@Test
	public void test_listClientPeople() {
		List<Person> clientPeople = personDao.ListClientPeople(1);
		Assert.assertThat(clientPeople.size(), equalTo(2));
	}

}

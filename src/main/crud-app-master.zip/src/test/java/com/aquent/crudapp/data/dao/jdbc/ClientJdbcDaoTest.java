package com.aquent.crudapp.data.dao.jdbc;

import java.util.List;

import static org.hamcrest.core.IsEqual.equalTo;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.aquent.crudapp.data.dao.ClientDao;
import com.aquent.crudapp.domain.Client;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/application-beans.xml"})
public class ClientJdbcDaoTest {
	
	@Autowired
	ClientDao clientDao;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test_listClients() {
		List<Client> clients = clientDao.listClients();
		Assert.assertThat(clients.size(), equalTo(1));
	}
	
	@Test
	public void test_readClient() {
		Client client = clientDao.readClient(1);
		boolean clientFlag = true;
		if (!client.getCompanyName().equals("Aquent")) {
			clientFlag = false;
		} if (!client.getUri().equals("http://www.aquent.com")) {
			clientFlag = false;
		} if (!client.getPhoneNumber().equals("(617)535-5000")) {
			clientFlag = false;
		} if (!client.getStreetAddress().equals("501 Boylston St")) {
			clientFlag = false;
		} if (!client.getCity().equals("Boston")) {
			clientFlag = false;
		} if (!client.getState().equals("MA")) {
			clientFlag = false;
		} if (!client.getZipCode().equals("02116")) {
			clientFlag = false;
		}
		
		Assert.assertThat(clientFlag, equalTo(true));
	}
	
	@Test
	public void test_updateClient() {
		Client client = clientDao.readClient(1);
		client.setCompanyName("ABC Corp");
		clientDao.updateClient(client);
		client = clientDao.readClient(1);
		Assert.assertTrue(client.getCompanyName().equals("ABC Corp"));
		
		client.setCompanyName("Aquent");
		clientDao.updateClient(client);
	}
	
	@Test
	public void test_createClient() {
		Client client = new Client();
		client.setCompanyName("Amalgamated Widgets");
		client.setUri("http://aw.com");
		client.setPhoneNumber("(781)555-1212");
		client.setStreetAddress("999 Anywhere Lane");
		client.setCity("Boston");
		client.setState("MA");
		client.setZipCode("06497");
		
		int id = clientDao.createClient(client);
		Client client2 = clientDao.readClient(id);
		
		boolean clientFlag = true;
		if (!client2.getCompanyName().equals("Amalgamated Widgets")) {
			clientFlag = false;
		} if (!client2.getUri().equals("http://aw.com")) {
			clientFlag = false;
		} if (!client2.getPhoneNumber().equals("(781)555-1212")) {
			clientFlag = false;
		} if (!client2.getStreetAddress().equals("999 Anywhere Lane")) {
			clientFlag = false;
		} if (!client2.getCity().equals("Boston")) {
			clientFlag = false;
		} if (!client2.getState().equals("MA")) {
			clientFlag = false;
		} if (!client2.getZipCode().equals("06497")) {
			clientFlag = false;
		}
		
		Assert.assertThat(clientFlag, equalTo(true));
		
		clientDao.deleteClient(id);
	}

}
